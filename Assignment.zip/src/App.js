import './App.css';
import Calculater from './components/Calculater';
function App() {
  return (
    <div className="App">
      <Calculater/>
    </div>
  );
}

export default App;
